-- ================================
-- ENABLE RLS
-- ================================

ALTER TABLE public.credits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.credit_logs ENABLE ROW LEVEL SECURITY;

-- ================================
-- READ OWN CREDITS
-- ================================

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'read own credits'
  ) THEN
    CREATE POLICY "read own credits"
    ON public.credits
    FOR SELECT
    USING (auth.uid() = user_id);
  END IF;
END $$;

-- ================================
-- READ OWN CREDIT LOGS
-- ================================

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'read own credit logs'
  ) THEN
    CREATE POLICY "read own credit logs"
    ON public.credit_logs
    FOR SELECT
    USING (auth.uid() = user_id);
  END IF;
END $$;

-- ❌ NO UPDATE / INSERT policies
-- Credits can ONLY change via RPC
